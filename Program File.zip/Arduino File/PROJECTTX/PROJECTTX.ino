#include <Wire.h>
#include "MAX30105.h"
#include "heartRate.h"
#include "spo2_algorithm.h"
#include <SPI.h>
#include <LoRa.h>
#include <SoftwareSerial.h>
#include <LiquidCrystal_I2C.h>

MAX30105 particleSensor;
SoftwareSerial gsm(D3, D4);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ---------------- LoRa pins ----------------
#define LORA_SS   15
#define LORA_RST  16
#define LORA_DIO0 -1

// ---------------- MPU6050 ----------------
const int MPU = 0x68;
float angleZ     = 0;
float gyroOffset = 0;
unsigned long prevTime   = 0;
unsigned long lastPrint  = 0;
const int PRINT_INTERVAL = 200;

// ---------------- Direction ----------------
int lastDirection = 0;

// ---------------- MAX30105 ----------------
#define BUFFER_LENGTH 50
#define AVG_SAMPLES   2

uint32_t irBuffer[BUFFER_LENGTH];
uint32_t redBuffer[BUFFER_LENGTH];
int32_t spo2, heartRate;
int8_t validSPO2, validHeartRate;
bool fingerWasOff = false;

int latestHR   = 0;
int latestSPO2 = 0;

// ---------------- Touch Sensor ----------------
#define TOUCH_PIN A0
bool lastTouchState    = false;
unsigned long lastTouchTime = 0;
const unsigned long TOUCH_DELAY = 300;

// ---------------- GSM / Hospital Config ----------------
#define PATIENT_NAME "VISHNU"

// Three hospitals — keyword triggers, numbers, names
const char* hospitalKeywords[] = { "vel hospital", "raj hospital", "deen hospital" };
const char* hospitalNumbers[]  = { "+918438033848", "+919344997231", "+919092206521" };
const char* hospitalNames[]    = { "VEL Hospital",    "RAJ Hospital",    "DEEN Hospital"   };
const int   NUM_HOSPITALS      = 3;

// ---------------- Non-blocking Call State ----------------
bool          callInProgress = false;
unsigned long callEndTime    = 0;
const unsigned long CALL_DURATION_MS = 10000; // 10 seconds

// ---- LCD HELPERS ----
void lcdPrint(String row1, String row2) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(row1.substring(0, 16));
  lcd.setCursor(0, 1);
  lcd.print(row2.substring(0, 16));
}

void lcdShowHealth(int hr, int sp) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("    HEALTH      ");
  lcd.setCursor(0, 1);
  if (hr > 0 && sp > 0) {
    String row2 = "HR:" + String(hr) + " SPO2:" + String(sp) + "%";
    lcd.print(row2.substring(0, 16));
  } else {
    lcd.print("HR:-- SPO2:--%  ");
  }
}

// ---- CONDITION CHECK ----
String getCondition(int hr, int sp) {
  if (hr >= 60 && hr <= 100 && sp >= 95) return "NORMAL";
  if (sp < 90)                            return "CRITICAL - LOW SPO2";
  if (hr > 100)                           return "WARNING - HIGH HEART RATE";
  if (hr < 60)                            return "WARNING - LOW HEART RATE";
  return "ABNORMAL";
}

// ---- SEND AT COMMAND (non-blocking friendly) ----
void sendAT(String cmd, int wait = 1000) {
  gsm.println(cmd);
  delay(wait);
  while (gsm.available()) Serial.write(gsm.read());
  Serial.println();
}

// ---- SEND SMS (message sent as-is) ----
void sendSMS(const char* number, String message) {
  sendAT("AT+CMGF=1", 500);

  gsm.println("AT+CMGS=\"" + String(number) + "\"");
  delay(1500);
  while (gsm.available()) gsm.read();

  gsm.print(message);   // send message exactly as received
  delay(500);
  gsm.write(26);        // Ctrl+Z
  delay(5000);

  while (gsm.available()) Serial.write(gsm.read());
  Serial.println("\nSMS Sent to " + String(number));
}

// ---- MAKE CALL (non-blocking — starts call, hangup handled in loop) ----
void startCall(const char* number) {
  gsm.println("ATD" + String(number) + ";");
  delay(500);
  while (gsm.available()) Serial.write(gsm.read());

  callInProgress = true;
  callEndTime    = millis() + CALL_DURATION_MS;

  Serial.println("[CALL] Calling " + String(number) + " for 10 seconds...");
}

// ---- CHECK AND HANG UP CALL (called every loop iteration) ----
void handleCall() {
  if (!callInProgress) return;

  if (millis() >= callEndTime) {
    gsm.println("ATH"); // hang up
    delay(500);
    while (gsm.available()) Serial.write(gsm.read());
    callInProgress = false;
    Serial.println("[CALL] Hung up.");

    // Restore LCD after call ends
    lcdShowHealth(latestHR, latestSPO2);
  }
}

// ---- SEND PATIENT REPORT ----
void sendPatientReport(int hospitalIndex, int hr, int sp) {
  const char* number = hospitalNumbers[hospitalIndex];
  String condition   = getCondition(hr, sp);

  String msg = "";
  msg += "PATIENT - " + String(PATIENT_NAME) + "\n";
  msg += "HEART RATE - " + String(hr) + " BPM\n";
  msg += "SPO2 - " + String(sp) + " %\n";
  msg += "CONDITION - " + condition;

  Serial.println("--- Sending Patient Report to " + String(hospitalNames[hospitalIndex]) + " ---");
  Serial.println(msg);

  sendSMS(number, msg);
}

// ---- CHECK INCOMING SMS ----
void checkGSM() {
  if (!gsm.available()) return;

  delay(300);
  String raw = "";
  while (gsm.available()) {
    raw += (char)gsm.read();
    delay(2);
  }

  Serial.println("GSM RAW: " + raw);

  String msg = raw;
  msg.toLowerCase();
  msg.replace("\r", " ");
  msg.replace("\n", " ");
  msg.trim();

  Serial.println("PROCESSED: " + msg);

  for (int i = 0; i < NUM_HOSPITALS; i++) {
    if (msg.indexOf(hospitalKeywords[i]) >= 0) {
      Serial.print(">>> ");
      Serial.print(hospitalNames[i]);
      Serial.println(" request received!");

      if (latestHR > 0 && latestSPO2 > 0) {
        sendPatientReport(i, latestHR, latestSPO2);
      } else {
        String fallback = "PATIENT - " + String(PATIENT_NAME) + "\nNo reading yet. Place finger on sensor.";
        sendSMS(hospitalNumbers[i], fallback);
      }

      if (!callInProgress) {
        startCall(hospitalNumbers[i]);
        lcd.setCursor(0, 0);
        lcd.print(" SMS SENT!      ");
        lcd.setCursor(0, 1);
        String callNote = "Calling " + String(hospitalNames[i]);
        lcd.print(callNote.substring(0, 16));
      }

      return;
    }
  }
}

// ---- DIRECTION DETECT ----
int getDirection(float angle) {
  float a = fmod(angle, 360.0);
  if (a < 0) a += 360.0;
  if (a >= 315 || a < 45)  return 1;
  if (a >= 45  && a < 135) return 4;
  if (a >= 135 && a < 225) return 3;
  if (a >= 225 && a < 315) return 2;
  return 1;
}

String directionName(int d) {
  if (d == 1) return "North";
  if (d == 2) return "East";
  if (d == 3) return "South";
  if (d == 4) return "West";
  return "Unknown";
}

// ---- LORA SEND ----
void sendLoRa(int direction) {
  String msg = String(direction) + ":" + directionName(direction);
  LoRa.beginPacket();
  LoRa.print(msg);
  LoRa.endPacket();
  Serial.println("[LoRa SENT] " + msg);

  lcdPrint("LoRa Sent!", "Dir:" + directionName(direction));
  delay(1500);
  lcdShowHealth(latestHR, latestSPO2);
}

// ---- TOUCH SENSOR CHECK ----
void checkButton() {
  int raw = analogRead(TOUCH_PIN);
  bool currentState = (raw > 900);

  if (currentState == true && lastTouchState == false) {
    if (millis() - lastTouchTime > TOUCH_DELAY) {
      lastTouchTime = millis();
      Serial.println("[TOUCH] Detected — sending direction via LoRa");
      sendLoRa(lastDirection);
    }
  }
  lastTouchState = currentState;
}

// ---- GYRO CALIBRATION ----
void calibrateGyro() {
  long sum = 0;
  Serial.println("Keep MPU STILL — 5 seconds...");

  for (int i = 5; i > 0; i--) {
    lcdPrint("Keep Still!", "Calibrating: " + String(i));
    delay(1000);
  }

  for (int i = 0; i < 3000; i++) {
    Wire.beginTransmission(MPU);
    Wire.write(0x47);
    Wire.endTransmission(false);
    Wire.requestFrom(MPU, 2, true);
    int16_t gz = Wire.read() << 8 | Wire.read();
    sum += gz;
    delay(2);
  }

  gyroOffset = (sum / 3000.0) / 131.0;
  Serial.print("Gyro Offset: "); Serial.println(gyroOffset, 4);
  Serial.println("Calibration Done!");

  lcdPrint("System Ready", "For Command");
  delay(2000);
}

// ---- GYRO UPDATE ----
void updateYaw() {
  Wire.beginTransmission(MPU);
  Wire.write(0x47);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU, 2, true);

  int16_t raw = Wire.read() << 8 | Wire.read();
  float gz = (raw / 131.0) - gyroOffset;
  if (abs(gz) < 2.5) gz = 0;

  unsigned long now = millis();
  float dt = (now - prevTime) / 1000.0;
  if (dt <= 0 || dt > 1) { prevTime = now; return; }

  prevTime = now;
  angleZ  += gz * dt;

  int newDir = getDirection(angleZ);
  if (newDir != lastDirection) {
    lastDirection = newDir;
    Serial.print("Direction changed: ");
    Serial.print(newDir); Serial.print(" = ");
    Serial.println(directionName(newDir));
  }
}

// ---- CONTINUOUS PRINT ----
void printAll(int hr, int sp) {
  if (millis() - lastPrint < PRINT_INTERVAL) return;
  lastPrint = millis();

  Serial.print("Yaw: "); Serial.print(angleZ, 2);
  Serial.print(" | Dir: "); Serial.print(lastDirection);
  Serial.print(" ("); Serial.print(directionName(lastDirection)); Serial.print(")");
  if (hr > 0) {
    Serial.print(" | HR: "); Serial.print(hr);
    Serial.print(" bpm | SpO2: "); Serial.print(sp); Serial.print(" %");
  } else {
    Serial.print(" | HR: -- | SpO2: --");
  }
  Serial.println();
}

// ---- COLLECT BUFFER ----
bool collectBuffer() {
  for (int i = 0; i < BUFFER_LENGTH; i++) {
    updateYaw();
    checkButton();
    handleCall();   // keep call timer ticking even during buffer collection
    printAll(latestHR, latestSPO2);

    while (!particleSensor.available()) particleSensor.check();

    redBuffer[i] = particleSensor.getRed();
    irBuffer[i]  = particleSensor.getIR();
    particleSensor.nextSample();

    if (irBuffer[i] < 30000) {
      fingerWasOff = true;
      return false;
    }
  }
  return true;
}

void setup() {
  Serial.begin(115200);
  gsm.begin(9600);

  Wire.begin(4, 5);
  lcd.init();
  lcd.backlight();

  lcdPrint("System Started", "Initialising...");
  delay(2000);

  Wire.beginTransmission(MPU);
  Wire.write(0x6B);
  Wire.write(0);
  Wire.endTransmission(true);
  delay(1000);

  calibrateGyro();
  prevTime = millis();

  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);
  if (!LoRa.begin(433E6)) {
    Serial.println("LoRa init failed!");
    lcdPrint("LoRa FAILED!", "Check Wiring");
    while (true);
  }
  Serial.println("LoRa Ready!");

  if (!particleSensor.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("MAX30105 not found!");
    lcdPrint("MAX30105", "NOT FOUND!");
    while (true);
  }
  particleSensor.setup(30, 4, 2, 400, 411, 4096);

  lcdPrint("GSM Init...", "Please Wait");
  delay(8000);
  sendAT("AT");
  sendAT("AT+CMGF=1");
  sendAT("AT+CREG?");
  sendAT("AT+CNMI=1,2,0,0,0");

  Serial.println("System Ready. Place finger...");
  lcdPrint("System Idle", "Place Finger...");
}

void loop() {
  updateYaw();
  checkButton();
  handleCall();   // ← non-blocking 10s call hangup check
  printAll(latestHR, latestSPO2);
  checkGSM();

  while (true) {
    updateYaw();
    checkButton();
    handleCall();   // ← keeps running during finger wait too
    printAll(latestHR, latestSPO2);
    checkGSM();

    while (!particleSensor.available()) particleSensor.check();
    uint32_t ir = particleSensor.getIR();
    particleSensor.nextSample();

    if (ir > 30000) break;

    if (!fingerWasOff) {
      Serial.println("Waiting for finger...");
      lcdPrint("System Idle", "Place Finger...");
      fingerWasOff = true;
    }
    delay(50);
  }

  if (fingerWasOff) {
    Serial.println("Finger detected! Hold still...");
    lcdPrint("Hold Still...", "Reading...");
    fingerWasOff = false;
    delay(500);
  }

  int hrSum = 0, spo2Sum = 0, validCount = 0;

  for (int r = 0; r < AVG_SAMPLES; r++) {
    if (!collectBuffer()) {
      Serial.println("Finger removed.");
      lcdPrint("System Ready", "To Response...");
      return;
    }

    maxim_heart_rate_and_oxygen_saturation(
      irBuffer, BUFFER_LENGTH, redBuffer,
      &spo2, &validSPO2, &heartRate, &validHeartRate
    );

    if (validHeartRate && validSPO2 &&
        heartRate > 50 && heartRate < 150 && spo2 > 80) {
      hrSum   += heartRate;
      spo2Sum += spo2;
      validCount++;
    }

    updateYaw();
    checkButton();
    handleCall();
    printAll(latestHR, latestSPO2);
  }

  if (validCount > 0) {
    latestHR   = hrSum / validCount;
    latestSPO2 = spo2Sum / validCount;

    Serial.println("==============================");
    Serial.print("Heart Rate : "); Serial.print(latestHR);   Serial.println(" bpm");
    Serial.print("SpO2       : "); Serial.print(latestSPO2); Serial.println(" %");
    Serial.print("Direction  : "); Serial.println(directionName(lastDirection));
    Serial.print("Condition  : "); Serial.println(getCondition(latestHR, latestSPO2));
    Serial.println("==============================");

    lcdShowHealth(latestHR, latestSPO2);
  } else {
    Serial.println("Unstable — hold still.");
    lcdPrint("Unstable!", "Hold Still...");
  }

  delay(100);
}