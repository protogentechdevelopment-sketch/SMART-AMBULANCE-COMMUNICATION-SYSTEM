#include <TM1637Display.h>
#include <SPI.h>
#include <LoRa.h>

/* =========================================================
   PIN CONFIGURATION
   ========================================================= */
#define CLK 21
#define DIO 22
TM1637Display display(CLK, DIO);

#define N_RED 13
#define N_YEL 12
#define N_GRN 14

#define E_RED 27
#define E_YEL 26
#define E_GRN 25

#define S_RED 33
#define S_YEL 32
#define S_GRN 3

#define W_RED 16
#define W_YEL 17
#define W_GRN 15

#define LORA_SS    5
#define LORA_RST   4
#define LORA_SCK   18
#define LORA_MISO  19
#define LORA_MOSI  23

int currentAxis = 1;

/* =========================================================
   NAME HELPERS
   ========================================================= */
String dirName(int dir) {
  switch (dir) {
    case 1: return "NORTH";
    case 2: return "EAST";
    case 3: return "SOUTH";
    case 4: return "WEST";
  }
  return "UNKNOWN";
}

String axisName(int axis) {
  return (axis == 1) ? "NORTH-SOUTH" : "EAST-WEST";
}

/* =========================================================
   SIGNAL CONTROL
   ========================================================= */
void allOff() {
  digitalWrite(N_RED, LOW); digitalWrite(N_YEL, LOW); digitalWrite(N_GRN, LOW);
  digitalWrite(E_RED, LOW); digitalWrite(E_YEL, LOW); digitalWrite(E_GRN, LOW);
  digitalWrite(S_RED, LOW); digitalWrite(S_YEL, LOW); digitalWrite(S_GRN, LOW);
  digitalWrite(W_RED, LOW); digitalWrite(W_YEL, LOW); digitalWrite(W_GRN, LOW);
}

void setAllRed() {
  allOff();

  digitalWrite(N_RED, HIGH);
  digitalWrite(E_RED, HIGH);
  digitalWrite(S_RED, HIGH);
  digitalWrite(W_RED, HIGH);
}

void setAxisGreen(int axis, bool yellow = false) {
  setAllRed();

  if (axis == 1) {
    digitalWrite(N_RED, LOW);
    digitalWrite(S_RED, LOW);

    if (yellow) {
      digitalWrite(N_YEL, HIGH);
      digitalWrite(S_YEL, HIGH);
    } else {
      digitalWrite(N_GRN, HIGH);
      digitalWrite(S_GRN, HIGH);
    }
  }
  else {
    digitalWrite(E_RED, LOW);
    digitalWrite(W_RED, LOW);

    if (yellow) {
      digitalWrite(E_YEL, HIGH);
      digitalWrite(W_YEL, HIGH);
    } else {
      digitalWrite(E_GRN, HIGH);
      digitalWrite(W_GRN, HIGH);
    }
  }
}

void setSingleDirectionGreen(int dir) {
  setAllRed();

  switch (dir) {
    case 1:
      digitalWrite(N_RED, LOW);
      digitalWrite(N_GRN, HIGH);
      break;

    case 2:
      digitalWrite(E_RED, LOW);
      digitalWrite(E_GRN, HIGH);
      break;

    case 3:
      digitalWrite(S_RED, LOW);
      digitalWrite(S_GRN, HIGH);
      break;

    case 4:
      digitalWrite(W_RED, LOW);
      digitalWrite(W_GRN, HIGH);
      break;
  }
}

/* =========================================================
   LORA INTERRUPT CHECK
   ========================================================= */
int checkInterrupt() {
  int packetSize = LoRa.parsePacket();

  if (packetSize) {
    String msg = "";

    while (LoRa.available()) {
      msg += (char)LoRa.read();
    }

    msg.trim();

    Serial.print("[LoRa] Packet Received: ");
    Serial.println(msg);

    if (msg.startsWith("1")) return 1;
    if (msg.startsWith("2")) return 2;
    if (msg.startsWith("3")) return 3;
    if (msg.startsWith("4")) return 4;
  }

  return -1;
}

/* =========================================================
   EMERGENCY MODE
   ========================================================= */
void runEmergency(int dir) {
  Serial.println("\n=======================================");
  Serial.print("[EMERGENCY ACTIVE] Direction: ");
  Serial.println(dirName(dir));
  Serial.println("=======================================\n");

  for (int t = 30; t >= 0; t--) {
    display.showNumberDec(t, true);

    setSingleDirectionGreen(dir);

    Serial.print("[EMERGENCY] ");
    Serial.print(dirName(dir));
    Serial.print(" GREEN | ");
    Serial.print(t);
    Serial.println(" sec");

    delay(1000);
  }

  Serial.println("[EMERGENCY COMPLETE]\n");
}

/* =========================================================
   NORMAL TRAFFIC PHASE
   ========================================================= */
int runNormalAxis(int axis) {

  int emergencyDir = -1;

  for (int t = 30; t >= 0; t--) {

    bool yellow = (t <= 2);

    display.showNumberDec(t, true);
    setAxisGreen(axis, yellow);

    Serial.print("[NORMAL] ");
    Serial.print(axisName(axis));
    Serial.print(yellow ? " YELLOW | " : " GREEN  | ");
    Serial.print(t);
    Serial.println(" sec");

    for (int i = 0; i < 20; i++) {

      int intr = checkInterrupt();

      if (intr != -1 && emergencyDir == -1) {
        emergencyDir = intr;

        if (t > 5) {
          Serial.println("[INTERRUPT] Emergency Received → Reducing Timer To 5 sec");
          t = 5;
          display.showNumberDec(t, true);
        }
      }

      delay(50);
    }
  }

  return emergencyDir;
}

/* =========================================================
   SETUP
   ========================================================= */
void setup() {
  Serial.begin(115200);

  display.setBrightness(7);

  pinMode(N_RED, OUTPUT);
  pinMode(N_YEL, OUTPUT);
  pinMode(N_GRN, OUTPUT);

  pinMode(E_RED, OUTPUT);
  pinMode(E_YEL, OUTPUT);
  pinMode(E_GRN, OUTPUT);

  pinMode(S_RED, OUTPUT);
  pinMode(S_YEL, OUTPUT);
  pinMode(S_GRN, OUTPUT);

  pinMode(W_RED, OUTPUT);
  pinMode(W_YEL, OUTPUT);
  pinMode(W_GRN, OUTPUT);

  setAllRed();

  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_SS);
  LoRa.setPins(LORA_SS, LORA_RST);

  Serial.println("Initializing LoRa...");

  if (!LoRa.begin(433E6)) {
    Serial.println("LoRa Init Failed!");
    while (1);
  }

  Serial.println("LoRa Ready.");
  Serial.println("System Started.\n");
}

/* =========================================================
   MAIN LOOP
   ========================================================= */
void loop() {

  int emergencyDir = runNormalAxis(currentAxis);

  if (emergencyDir != -1) {
    runEmergency(emergencyDir);
  }

  currentAxis = (currentAxis == 1) ? 2 : 1;
}